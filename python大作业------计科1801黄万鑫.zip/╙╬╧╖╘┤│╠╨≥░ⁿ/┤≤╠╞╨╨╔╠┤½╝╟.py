import os
import shutil
import time
import tkinter as tk
import tkinter.messagebox
import winsound
import pygame
import win32com.client
speak=win32com.client.Dispatch('SAPI.SPVOICE')

cityList = []
siteList = []
CityName=[]
directions = ('north', 'south', 'west', 'east')

class role():
        def __init__(self):
                        self.name = '唐小商'
                        self.detail = '你是一个商人,目标就是赚钱'
                        self.money = 200
                        self.target = 10000
                        self.cityName = '长安'
                        self.siteName = '中心广场'
                        self.coordinate = (2, 1)
                        self.citysite = (0, 0)
                        good1 = Good('打狗棒', 0, 1,'长安')
                        good2 = Good('破碗', 0, 1,'长安')
                        self.goods = []
                        self.goods.append(good1)
                        self.goods.append(good2)

        def showMe(self):
                insertText("*"*50)
                insertText(self.name,  self.detail)
                insertText("你现在拥有白银**", self.money, "**两,","你的目标是挣够白银**", self.target, "**两。")
                insertText("你现在所处的位置是", self.cityName, "的", self.siteName)
                insertText("你身上携带以下物品：\n名称\t单价\t数量\t产地")
                for good in self.goods:
                        insertText(good.name, '\t' , good.price, '\t', good.number,'\t',good.origin)
                insertText("*"*50)

        def config(self, city, site):
                self.city = city
                self.cityName = city.name
                self.site = site
                self.siteName = site.name
                self.coordinate = city.coordinate
                self.citysite = site.coordinate

        def move(self, direction):
                if direction not in self.site.neighb:
                        insertText("很遗憾，这个方向没有路或者出口！！！")
                        return
                insertText('*'*30)
                insertText('你朝--', self.site.neighb[direction].name, '--走去')
                speak=win32com.client.Dispatch('SAPI.SPVOICE')
                speak.Speak('你朝--'+self.site.neighb[direction].name+'--走去')
                if type(self.site.neighb[direction]) == City:
                        insertText("路途遥远，正在拼命赶路中")

                        window2 = tk.Tk()
                        window2.title("".join("从"+self.cityName+"赶路到"+self.site.neighb[direction].name))
                        canvas = tk.Canvas(window2,width=400,height=200)
                        canvas.pack()
                        fill = canvas.create_rectangle(5,5,40,25,outline = "",width = 0,fill = "blue")
                        canvas.create_rectangle(5,5,400,25,outline = "blue",width = 1)
                        canvas.create_text(150,100,text= "正在拼命赶路中，城市之间移动消耗50两银子", font = "time 10  bold underline",fill='red')
                        for x in range(0,60):
                                canvas.move(1,5,0)  ##把任意画好的对象移动到把x和y坐标增加给定值的位置
                                canvas.coords(fill, (5, 10, 6 + (x/60)*400, 25))
                                window2.update()         ##强制tkinter更新屏幕（重画）     
                                time.sleep(0.1)   
                        window2.destroy()
                        city = self.site.neighb[direction]
                        insertText(self.city.name, '----->', city.name)
                        self.changeCity(self.city, city)
                        for city in cityList:
                                REWloadShop(city)

                        

                else:
                        self.site = self.site.neighb[direction]
                        self.siteName = self.site.name
                        self.citysite = self.site.coordinate
                insertText('你来到--', self.site.name, '--')
                speak=win32com.client.Dispatch('SAPI.SPVOICE')
                speak.Speak('你来到--'+self.site.name)

        def changeCity(self, city1, city2):
                if len(city2.siteList) <= 0:
                        loadCity(city2)#"转移城市加载
                        loadStore(city2)#load move city shop"
                self.city = city2
                self.cityName = city2.name
               
        
                find = False
                for site in city2.siteList:
                        
                        for direction in directions:
                                if direction in site.neighb:
                                        temp = site.neighb[direction]
                                        if  temp != "" and temp.name == city1.name:
                                                self.site = site
                                                find = True
                                                break
                        if find:
                                break
                self.siteName = self.site.name
                self.citysite = self.site.coordinate
                self.money -=50
                insertText("用了五天时间,花费50两银子")

        def buy(self, commandList):
                if type(self.site) is not Store:
                        insertText('只有在商店才能进行交易！！！\n\n')
                        return
                lenth = len(commandList)
                needed = 0
                flag = False
                flag2 = False
                goodsList = self.site.goods
                for good in goodsList:
                        if good.number>0:
                                flag2 = True
                                break
                if not flag2:
                        insertText("店小二：客官对不起，本店商品已售空\n\n")
                        return
                if lenth == 1:
                        for goods in goodsList:
                                needed += goods.price * goods.number
                        if self.money >= needed:
                                self.money -= needed
                                for goods in goodsList:
                                        for good in self.goods:
                                                if (goods.name == good.name) and (goods.origin == good.origin) :
                                                        good.number += goods.number
                                                        goods.number = 0
                                                        break
                                for goods in goodsList:
                                        if goods.number > 0:
                                                good = Good(goods.name, goods.price, goods.number,goods.origin)
                                                self.goods.append(good)
                                                goods.number = 0
                                                flag = True
                                insertText("店小二：本店物品都都已经出售给您\n\n")
                        else:
                                insertText("店小二：你的钱不够!!!\n\n")
                elif lenth == 2:
                        logic = True
                        for goods in goodsList:
                                if goods.name == commandList[1]:
                                        needed = goods.price*goods.number
                                        logic = False
                                        break
                        if logic:
                                insertText("店小二：本店不出售{}商品\n\n".format(commandList[1]))
                        
                        if self.money >= needed:
                                self.money -= needed
                                find = False
                                for good in role1.goods:
                                        if (goods.name == good.name) and (goods.origin == good.origin):
                                                good.number += goods.number
                                                find = True
                                                break
                                if not find:
                                        good = Good(goods.name, goods.price, goods.number,goods.origin)
                                        self.goods.append(good)

                                goods.number = 0
                                flag = True
                        else:
                                insertText("你的钱不够\n\n")
                elif lenth == 3:
                        flag1 = False
                        num = int(commandList[2])
                        for goods in goodsList:
                                if goods.name == commandList[1]:
                                    flag1 = True
                                    if num > goods.number or num<=0 :
                                        insertText("店小二：超过或者低于本店的出售商品数量，只能卖给你商品数量为{}\n\n".format(goods.number))
                                        num = goods.number
                                    needed = goods.price*num
                                    break
                        if flag1:

                            if self.money >= needed:
                                    self.money -= needed
                                    find = False
                                    for good in self.goods:
                                            if (goods.name == good.name) and (goods.origin == good.origin):
                                                    good.number += num
                                                    find = True
                                                    break
                                    if not find:
                                            good = Good(goods.name, goods.price, num,goods.origin)
                                            self.goods.append(good)
                                    goods.number -= num
                                    flag = True
                            else:
                                    insertText("你的钱不够!!\n\n")
                        else:
                            insertText("店小二：本店不出售{}\n\n".format(commandList[1]))
                else:
                        insertText("店小二：不明白你在说啥\n\n")
                if flag:
                        if needed > 0:
                                insertText("你花了{}两银子，购买成功\n\n".format(needed))
                        else:
                                insertText("购买失败\n\n")

        def sell(self, commandList):
                if type(self.site) is not Store:
                        insertText("你在{}之内".format(self.site))
                        insertText('只有在商店内才能交易\n\n')
                        return
                else:
                        goodsList = self.goods
                        if len(goodsList) <= 0:
                                insertText("店小二：你没有什么可以卖的\n\n")
                                return
                        lenth = len(commandList)
                        income = 0
                        increase = 2
                        if lenth == 1:
                                for goods in goodsList:
                                        rate = Rate(goods,self.city)
                                        income += round(goods.number*goods.price*rate)
                                self.money += income
                                goodsList.clear()
                                insertText("店小二：客官您已经成功卖出所有商品\n\n")
                        elif lenth == 2:
                                loc = -1
                                for goods in goodsList:
                                        loc += 1
                                        logic = False
                                        if goods.name == commandList[1]:
                                                logic =True
                                                rate = Rate(goods,self.city)
                                                income = round(goods.price*goods.number*rate)
                                                del goodsList[loc]
                                                break
                                        self.money += income
                                        if logic:
                                                insertText("店小二：客官您已经成功卖出{}\n\n".format(commandList[1]))
                                        else :
                                                insertText("店小二：客官您没有这个{}物品\n\n".format(commandList[1]))
                                                return
                                        
                        elif lenth == 3:
                                num = int(commandList[2])
                                loc = -1
                                for goods in goodsList:
                                        loc += 1
                                        if goods.name == commandList[1]:
                                                if 0< num <= goods.number:
                                                    rate = Rate(goods,self.city)
                                                    income = round(goods.price*goods.number*rate)
                                                    break
                                                else:
                                                        insertText("店小二：客官您的{}商品数量有{},请输入1~{}的数字\n\n".format(commandList[1],goods.number,goods.number))
                                                        return
                                goods.number -= num
                                if goods.number <= 0:
                                        del goodsList[loc]
                                self.money += income
                        
                        else:
                                insertText("店小二：客官听不懂您在说啥\n\n")
                                return
                        insertText("店小二：你获得{}两收入\n\n".format(income))

        def reset(self):
            for file in  os.listdir("data"):
               shutil.copy("data\\"+file,L.account+"\\"+file) 
            role1 = loadRole()  
             
                

        def save(self):
                        with open(L.account+"//"+"\\save.txt", 'w',encoding='UTF-8-sig') as f:
                                f.write(self.name+'\n')
                                f.write(self.detail+'\n')
                                f.write(str(self.money)+'\n')
                                f.write(str(self.target)+'\n')
                                f.write(self.cityName+'\n')
                                f.write(self.siteName+'\n')
                                f.write(str(self.city.coordinate)+'\n')
                                f.write(str(self.site.coordinate)+'\n')
                                for good in self.goods:
                                        f.write(''.join(map(str,[good.name,' ',good.price,' ',good.number,' ',good.origin]))+'\n')
                        f.close()
                        insertText("角色保存成功\n\n")

        def showPosition(self):
                insertText('\n')
                insertText('*'*50)
                site = self.site
                if type(site) == Store:
                        insertText("你位于--",self.cityName,"--的--",site.name,"--里")
                        insertText("店里面有一下商品：\n 商品名称\t单价\t数量\t产地\n")
                        for good in site.goods:
                                insertText(good.name,'\t',good.price,'\t',good.number,'\t',good.origin)
                                insertText('\n')
                else:
                        insertText("你站在--",self.cityName,'--的--',site.name,'--上')
                if len(site.neighb)>0 :
                        insertText("你可以去往：")
                        for direction in directions:
                                if direction in site.neighb:
                                        insertText(direction,site.neighb[direction])
                                        insertText('\n')

class Site():
        def __init__(self,name,coordinate):
                self.name = name
                self.coordinate= coordinate
                self.neighb = dict()
        def addNeighb(self,key,value):
                self.neighb[key] = value
        def __str__(self):
                return self.name

class Store(Site):
        def __init__(self,name,coordinate):
                super().__init__(name,coordinate)
                self.goods = list()
        def addCommodity(self,good):
                self.goods.append(good)

class City(Site):
        def __init__(self,name,coordinate):
                super().__init__(name,coordinate)
                self.siteList=[]
        def save(self):
                with open(L.account+"//shop_"+self.name+".txt",'w',encoding='UTF-8-sig') as f:
                        for site in self.siteList:
                                if type(site) ==Store:
                                        f.write('0 '+site.name+'\n')
                                        for good in site.goods:
                                                f.write('1 '+' '.join(map(str,[good.name,good.number, good.price,good.origin]))+'\n')
                f.close()
        def addPosition(self,site):
                self.siteList.append(site)
        
        def configCityNeighbour(self):
                for direction in directions:
                        if direction in self.neighb:
                                for city in cityList:
                                        if city.name == self.neighb[direction]:
                                                self.neighb[direction] = city
                                                break
                
        def configPositoinNeighbour(self,site):
                for direction in directions:
                        if direction in site.neighb:
                                if site.neighb[direction] in CityName :#确认城市
                                        for temp in cityList:
                                                if temp.name == site.neighb[direction]:
                                                        site.neighb[direction] = temp
                                                        break
                                else:
                                        for temp in self.siteList:#确认其他地点
                                                if temp.name == site.neighb[direction]:
                                                        site.neighb[direction]=temp
                                                        break
                        
class Good:
        def __init__(self,name,price,number,origin):
                self.name = name
                self.price = price
                self.number = number
                self.origin = origin

class Account():
    accounts = dict()
    def __init__(self):
        try:
             with open("account.txt",encoding='UTF-8-sig') as f:
                while True:
                    line = f.readline().replace("\n","")
                    if not line:
                        break
                    line = line.split()
                    self.accounts[line[0]] = line[1]
        except FileNotFoundError:
            accounts={}

class login():
        account=None
        def __init__(self):
                self.root = tk.Tk()
                self.root.title("大唐行商传")
                self.root.geometry('300x200')
                self.root.geometry("+750+300")
                
                self.canvas = tk.Canvas(self.root,height=300,width = 200) 
                self.canvas.create_rectangle(20 , 20, 160, 100, fill = "green")
                self.canvas.create_rectangle(30, 30, 150, 90, fill = "yellow")
                
                self.canvas.create_text(90, 60 ,text = "大唐行商传",font = "time 15")

                #self.canvas.create_text(100,80,text= "大唐行商传", font = "time 25  bold underline",fill='red')
                self.canvas.pack(side='top')

                self.label_account = tk.Label(self.root, text = "账户:")
                self.label_password = tk.Label(self.root, text = "密码:")
                self.input_account= tk.Entry(self.root,width = 20)
                self.input_password = tk.Entry(self.root,show = '*',width =20)
                self.login_button = tk.Button(self.root,command = self.siginUp_interface,text = "登录")
                self.regist_button = tk.Button(self.root,command = self.backstage_interface,text = "注册")
                self.quit_button = tk.Button(self.root,command = self.root.destroy,text= "退出")

        
        def gui_arrange(self):
                self.label_account.place(x=50, y=110)
                self.label_password.place(x=50,y=140)
                self.input_account.place(x=80, y=110)
                self.input_password.place(x=80, y=140)
                self.login_button.place(x=50, y=165)
                self.regist_button.place(x=110, y=165)
                self.quit_button.place(x = 160, y = 165)
                self.root.mainloop()

        def siginUp_interface(self):

                account = self.input_account.get()
                password = self.input_password.get()
                accs = Account()
                
                if(account in accs.accounts):
                        if password == accs.accounts[account]:
     
                                tk.messagebox.showinfo( message ='欢迎登录')
                                self.account = account
                                self.root.destroy()
                        else:
                                tk.messagebox.showerror(message = '密码错误')
                elif account=='' or password == '':
                        self.input_password.delete(0,100)
                        tk.messagebox.showerror(message = '账号或密码为空')
                else:
                        signup=tk.messagebox.askyesno('此账户未注册，是否注册？')
                        if signup:
                                self.backstage_interface()
                        else:
                                self.root.destroy()

        def backstage_interface(self):
                account = self.input_account.get()
                password = self.input_password.get()

                accs = Account()
                if account=='' or password =='':
                        tk.messagebox.showerror('错误','用户名或者密码为空')
                
                elif account in accs.accounts:
                        tk.messagebox.showerror('错误','用户名已存在')
                        self.input_account.delete(0,100)
                        self.input_password.delete(0,100)
                else:
                        self.account = account
                        with open('account.txt','a+') as f:
                                f.writelines(''.join(self.account+' '+password+'\n'))
                        f.close()
                        shutil.copytree("data",account)
                        tk.messagebox.showinfo(title='测试系统', message='录入账户:{}\n密码：{}\n登录成功！'.format(self.account,password))
                        self.root.destroy()

class winGame():
        flag =0
        def cont(self):
                self.flag +=1
                if self.flag<2:
                        order=tkinter.messagebox.askyesno(title='游戏通关', message='恭喜你游戏通关,是否继续游戏？')
                        if not order:
                                role1.save()
                                os._exit(0)

def loadRole():
        self = role()
        with open(L.account+"//"+"save.txt" ,encoding='UTF-8-sig') as f:
                self.name = f.readline().replace("\n", "")
                self.detail = f.readline().replace("\n", "")
                self.money = int(f.readline().replace("\n", ""))
                self.target = int(f.readline().replace("\n", ""))
                self.cityName = f.readline().replace("\n", "")
                self.siteName = f.readline().replace("\n", "")
                self.citycoordinate = eval(f.readline().replace("\n", ""))
                self.citysite = eval(f.readline().replace("\n", ""))
                self.goods=[]
                for city in cityList:
                        loadCity(city)
                        loadStore(city)
                        if city.name == self.cityName:
                                roleCity = city
                                
                for site in roleCity.siteList:
                        if site in roleCity.siteList:
                                if site.coordinate == self.citysite:
                                        rolePosition = site
                                        break
                self.config(roleCity,rolePosition)
                while True:
                        fileline = f.readline().replace("\n", "")
                        if not fileline:
                                break
                        goods = fileline.split()
                        good = Good(goods[0],int(goods[1]),int(goods[2]),goods[3])######
                        self.goods.append(good)
        return self

def loadWorld():
        with open(L.account+"\\"+"map_world.txt",encoding='UTF-8-sig' ) as f :
                while True:
                        line = f.readline().replace('\n',"")
                        if not line:
                                break
                        templist = line.split()
                        city = City(templist[1], eval(templist[0]))
                        CityName.append(templist[1])
                        for i in range(2,len(templist),2):
                                city.addNeighb(templist[i],templist[i+1])
                        cityList.append(city)
                f.close
                for city in cityList:
                        city.configCityNeighbour()

def loadCity(city):
        with open(L.account+"//"+"map_"+city.name+".txt",encoding='UTF-8-sig') as f :
                while True:
                        line = f.readline().replace("\n","")
                        if not line:
                                break
                        templist = line.split()
                        site = Site(templist[1],eval(templist[0]))
                        for i in range(2,len(templist),2):
                                site.addNeighb(templist[i],templist[i+1])
                        city.siteList.append(site)
        f.close

def Rate(good,city):
    x1,y1 = city.coordinate
    for city1 in cityList:
        if good.origin == city1.name:
            x,y = city1.coordinate
            if(x1==x) and (y1==y):
                return 0.5
            else:
                return 1+((x1-x)**2+(y1-y)**2)/10

def loadStore(city):
        with open(L.account+"//shop_"+city.name+".txt",encoding='UTF-8-sig' ) as f:
                while True:
                        line = f.readline().replace('\n',"")
                        if not line:
                                break
                        templist = line.split()
                        if templist[0] == '0':
                                for site in city.siteList:
                                        if site.name == templist[1]:
                                                shop = Store(site.name,site.coordinate)
                                                for key in site.neighb:
                                                        shop.addNeighb(key,site.neighb[key])
                                                break
                                if shop:
                                        city.siteList.remove(site)
                                        city.siteList.append(shop)
                        else:
                                goods = templist
                                good = Good(goods[1],int(goods[2]),int(goods[3]),goods[4])
                                shop.addCommodity(good)
        for site in city.siteList:
                city.configPositoinNeighbour(site)

def REWloadShop(city):#刷新商店物品
        with open("data//shop_"+city.name+".txt",encoding='UTF-8-sig' ) as f:
                while True:
                        line = f.readline().replace('\n',"")
                        if not line:
                                break
                        templist = line.split()
                        if templist[0] == '0':
                                for shop in city.siteList:
                                        if shop.name == templist[1]:
                                                shop.goods.clear()
                                                shop1 = shop
                        else:
                                goods = templist
                                good = Good(goods[1],int(goods[2]),int(goods[3]),goods[4])
                                shop1.addCommodity(good)

def music(var):
        string = ''
        for i in var:
                string = string+i
        
        if string == 'music':
                pygame.mixer.init()
                pygame.mixer.music.load('BGM.mp3')
                pygame.mixer.music.play(-1)#b播放BGM
                insertText("打开背景音乐播放")
                insertText("播放音乐,暂停播放请输入：’music off‘")
        elif string =='musicoff':
                pygame.mixer.music.pause()
                insertText("暂停播放,重新播放请输入‘music on’")
                speak.Speak('暂停播放,重新播放请输入‘music on’')
        elif string =='musicon':
                pygame.mixer.music.unpause()  
                insertText("播放音乐,暂停播放请输入：’music off‘")
                speak.Speak('播放音乐,暂停播放请输入：’music off‘')
        else:
                insertText("错误命令，请重新输入，播放音乐：music on ，暂停播放：music off ")

def showIntro():
        with open('introduction.txt',encoding='UTF-8-sig') as f:
                while True:
                        text = f.readline()
                        if not text:
                                break
                        insertText(text)

def help():
        insertText('在命令栏输入命令后点击‘执行’按键或者‘回车键’即可执行命令')
        insertText('help----->获取命令栏')
        insertText('look----->查看角色周边信息')
        insertText("i------>查看角色自身状态")
        insertText('save---->保存游戏进度')
        insertText('reset--->重置游戏')
        insertText("buy---->购买商品")
        insertText("sell---->售出物品")
        insertText('quit---->保存并退出游戏')
        insertText('music---->播放背景音乐')
        insertText('music off---->关闭背景音乐')
        insertText('music on----->重启背景音乐')
        insertText('e, east----->分别代表往东方向移动')
        insertText('w,west----->分别代表往西方向移动')
        insertText('s,south----->分别代表往南方向移动')
        insertText('n,north----->分别代表往北方向移动')

def submit(ev = None):
        mainProcess()

def insertText(* var):
        text = "".join(map(str, var))+'\n'
        t.insert('insert', text)
        e.delete(0, 300)

def insertText1(* var):
        text = "".join(map(str, var))+'\n'
        t1.insert('insert', text)

def Showmap():
        pygame.init()                                
        screen = pygame.display.set_mode([600,450])       # 显示窗口
        background = pygame.image.load('map//'+role1.cityName+".gif")####.convert()
        running = True
        while running:
                screen.blit(background, (0, 0))
                pygame.display.update()
                for event in pygame.event.get():         
                        if event.type == pygame.QUIT:      
                                pygame.display.quit()
                                running = False
                                break

def showWindow():
        t1.delete('1.0', 'end')
        insertText1("名字：",role1.name)
        insertText1("金钱：",role1.money)
        insertText1("地点：",role1.cityName,"的",role1.siteName)
        insertText1("目标：赚够银子{}两".format(role1.target))
        if role1.goods == []:
                insertText1("物品： 空") 
        else:
                insertText1("背包物品：\t","单价\t","数量\t","产地\t")
                for good in role1.goods:
                        insertText1(good.name,'\t',good.price,'\t',good.number,'\t',good.origin)

def mainWindow():
        global L
        L = login()
        L.gui_arrange() 
        if L.account == None:
                os._exit(0)
        global window
        window=tk.Tk()
        window.geometry('1300x800')
        window.title('大唐行商传')
        global t1
        global t
        global e
        global canvas
        t=tk.Text(window, width=800, height=30)
        t.pack()
        e=tk.Entry(window, show=None, font=('Arial', 20), width=50)
        e.bind("<Return>", submit)
        e.pack()
        b1=tk.Button(window, text='执行（回车）',width=16, height=3, command=mainProcess)
        b1.pack()
        t1 = tk.Text(window, width=50, height=15)
        t1.place(x = 140, y =480)
        winsound.Beep(2300, 300)
        speak.Speak('欢迎来到大唐行商传')
        showIntro()
        loadWorld()
        global role1
        role1 = loadRole()
        canvas = tk.Canvas(window,width=400,height=700)
        global win 
        win= winGame()
        mainProcess()
        window.mainloop()
        
def mainProcess():
        showWindow()
        commandList=e.get().split()
        insertText(commandList)
        if len(commandList)<=0:
                return
        t.delete('1.0', 'end')
        t1.delete('1.0', 'end')
        command=commandList[0]
        if command=='look':
                role1.showPosition()
        elif command=='i':
                role1.showMe()        
        elif command in ('north','n'):
                role1.move('north')        
        elif command in ('south','s'):
                role1.move('south')        
        elif command in ('east','e'):
                role1.move('east')        
        elif command in ('west','w'):
                role1.move('west')        
        elif command=='buy':
                role1.buy(commandList)
        elif command=='sell':
                role1.sell(commandList)
        elif command in ('help','h'):
                help()
        elif command=='map':
                Showmap()
        elif command=='save':
                role1.save()
        elif command=='reset':
                role1.reset()
        elif command == 'music':
                music(commandList)
        elif command=='map':
                Showmap()
        elif command in ('quit','q'):
                for city in cityList:
                        city.save()
                role1.save()
                insertText("你离开了游戏，下一次将会从这里进入这个世界。。。")
                time.sleep(1)
                os._exit(0)
        else:
                insertText("命令输入错误,请重新输入!!!\n\n")
                help()
        if role1.money <=0:
                insertText("你没钱了，游戏结束")
                winsound.Beep(2300, 300)
                speak.Speak('你没钱了，游戏结束')
                role1.reset()
                os._exit(0)
        if role1.money>10000:
                win.cont()
        showWindow()
        role1.showPosition()

mainWindow()
